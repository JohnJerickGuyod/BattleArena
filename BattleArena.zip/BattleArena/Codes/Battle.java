package Polymorphism.Polymorphism2;

import java.util.List;

public class Battle {
    public static void fightRound(List<Fighter> attackers, List<Fighter> defenders){
        for (Fighter fighter : attackers) {
            if (fighter.isAlive()) {
                Fighter target = fighter.chooseTarget(defenders);
                if (target != null) {
                    fighter.attack(target);
                }
            }
        }
    }
    public static void printTeam(String label, List<Fighter> team){
        System.out.print(label + ": ");
        for (int i = 0; i < team.size(); i++) {
            System.out.print(team.get(i).describe() + " ");
        }
        System.out.println("");
    }

}
