package Polymorphism.Polymorphism2;

public class Warrior extends Fighter{
    Warrior(String name){
        super(name, 100);
    }
    @Override
    public int attackPower(){
        return 12;
    }
    @Override 
    public String getTitle(){
        return "Warrior";
    }
}
