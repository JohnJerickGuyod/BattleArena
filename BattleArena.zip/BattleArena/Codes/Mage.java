package Polymorphism.Polymorphism2;

import java.util.*;

public class Mage extends Fighter{
    Mage(String name){
        super(name, 70);
    }

    @Override
    public int attackPower(){
        return 20;
    }
    @Override 
    public String getTitle(){
        return "Mage";
    }
    @Override 
    public Fighter chooseTarget(List<Fighter> enemies) {
    Fighter lowestHpTarget = null;

    for (Fighter fighter : enemies) {
        if (fighter.isAlive()) {
            if (lowestHpTarget == null || fighter.getHp() < lowestHpTarget.getHp()) {
                lowestHpTarget = fighter;
            }
        }
    }
    return lowestHpTarget;
}
}
