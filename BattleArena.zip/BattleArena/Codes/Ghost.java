package Polymorphism.Polymorphism2;

public class Ghost extends Fighter {
    private int hitCounts = 0;
    Ghost(String name){
        super(name,60);
    }
    @Override 
    public int attackPower(){
        return 8;
    }
    
    @Override
    public String getTitle(){
        return "Ghost";
    }
    @Override 
    public void receiveHit(int damage){
        this.hitCounts++;
        if (this.hitCounts == 2) {
            this.hitCounts = 0;
        }else{
            super.receiveHit(damage);
        }
    }
    
}
