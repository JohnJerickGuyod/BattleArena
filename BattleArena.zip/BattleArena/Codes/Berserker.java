package Polymorphism.Polymorphism2;

public class Berserker extends Warrior{
    Berserker(String name){
        super(name);
    }
    @Override
    public int attackPower(){
        if (super.getHp() < 60) {
            return super.attackPower()*2;
        }else{
            return super.attackPower();
        }
    }
    @Override 
    public String getTitle(){
        return "Berserker";
    }
}
