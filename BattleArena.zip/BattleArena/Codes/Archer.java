package Polymorphism.Polymorphism2;

import java.util.List;

public class Archer extends Fighter{
    Archer(String name){
        super(name, 80);
    }
    @Override 
    public int attackPower(){
        return 10;
    }
    @Override 
    public String getTitle(){
        return "Archer";
    }
    @Override 
    public void attack(Fighter target){
        super.attack(target);
        super.attack(target);
    }
    @Override
    public Fighter chooseTarget(List<Fighter> enemies) {
        Fighter lastAlive = null;
        for (Fighter target : enemies) {
            if (target.isAlive()) {
                lastAlive = target;
            }
        }
        return lastAlive;
    }
}