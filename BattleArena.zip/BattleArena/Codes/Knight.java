package Polymorphism.Polymorphism2;

public class Knight extends Warrior{
    Knight(String name){
        super(name);
    }
    @Override
    public int attackPower(){
        return super.attackPower() + 3;
    }
    @Override 
    public void receiveHit(int damage){
        super.receiveHit(Math.max(1, damage - 4));
    }
    @Override 
    public String getTitle(){
        return "Knight";
    }
}
