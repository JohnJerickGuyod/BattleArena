package Polymorphism.Polymorphism2;
import java.util.*;
public class Fighter {

    private String name;
    private int hp;

    Fighter(String name, int  hp){
        this.name = name;
        this.hp = hp;
    }

    public String getName(){
        return this.name;
    }
    public boolean isAlive(){
        return hp > 0;
    }
    public int getHp(){
        return this.hp;
    }

    public int attackPower(){
        return 5;
    }
    public String getTitle(){
        return "Fighter";
    }
    public void receiveHit(int damage){
        this.hp -= damage;
        if (this.hp < 0) {
            this.hp = 0;
        }
    }
    public void attack(Fighter target){
        target.receiveHit(attackPower());
    }
    public Fighter chooseTarget(List<Fighter> enemies){
        for (Fighter fighter : enemies) {
            if (fighter.isAlive()) {
                return fighter;
            }
        }
        return null;
    }
    public String describe(){
        return  name + "(" + getTitle() + "):" + hp;
    }

}
