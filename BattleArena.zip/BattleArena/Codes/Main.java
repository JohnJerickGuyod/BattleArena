package Polymorphism.Polymorphism2;

import java.util.ArrayList;
import java.util.List;

public class Main {
    
    public static void main(String[] args) {

        List<Fighter> A = new ArrayList<>();
        List<Fighter> B = new ArrayList<>();
        
        A.add(new Knight("Arthur"));
        A.add(new Mage("Merlin"));
        A.add(new Archer("Robin"));

        B.add(new Berserker("Conan"));
        B.add(new Ghost("Casper"));
        B.add(new Warrior("Gimli"));
        
        for (int i = 0; i < 3; i++) {
            System.out.println("Round " + (i+1));
            Battle.fightRound(A, B);
            Battle.fightRound(B, A);
            Battle.printTeam("A", A);
            Battle.printTeam("B", B);
            System.out.println("--------------------------------------------------");
        }
    }
}
